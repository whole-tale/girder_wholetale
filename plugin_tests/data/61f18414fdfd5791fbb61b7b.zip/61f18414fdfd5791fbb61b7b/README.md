# Tale: "New better title" in BDBag Format

A better description

# Running locally

If you have Docker installed, you can run this Tale locally using the
following command:

```
sh ./run-local.sh
```

Access on http://localhost:8888/?token=wholetale
