echo "In the first run" > first_run.txt
