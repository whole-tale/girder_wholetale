echo "In the 2nd run" > second_run.txt
