# Tale: "Water Tale" in BDBag Format

Demonstration of how to use Whole Tale to develop custom analysis and visualization for data published externally via DataONE. See https://wholetale.readthedocs.io/en/stable/users_guide/quickstart.html for more information.

# Running locally

If you have Docker installed, you can run this Tale locally using the
following command:

```
sh ./run-local.sh
```

Access on http://localhost:8888/?token=wholetale
